package br.com.eng2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EngApplication {

	public static void main(String[] args) {
		SpringApplication.run(EngApplication.class, args);
	}
}
