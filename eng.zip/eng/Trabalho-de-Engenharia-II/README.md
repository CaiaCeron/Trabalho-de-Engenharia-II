# Instalação do Spring Boot:

1. Acesse o site do [SPRING](https://spring.io/)
- Siga o passo a passo das Imagens a seguir.
[![Foo](https://cdn.discordapp.com/attachments/169152372612923392/329053706320478210/unknown.png)](http://google.com.au/)
[![Foo](https://cdn.discordapp.com/attachments/169152372612923392/329053792316424193/unknown.png)](http://google.com.au/)
-Clique no botão 'Quick Start'.
[![Foo](https://cdn.discordapp.com/attachments/169152372612923392/329053860138319882/unknown.png)](http://google.com.au/)
- Clique no Link start.spring.io.
[![Foo](https://cdn.discordapp.com/attachments/169152372612923392/329053914957611019/unknown.png)](http://google.com.au/)
- Apos tudo acertado, clique no botão 'Generate Project'.
[![Foo](https://cdn.discordapp.com/attachments/169152372612923392/329054435441377282/unknown.png)](http://google.com.au/)
2. Apos o download feito vamos para a interface do Netbeans.
[![Foo](https://cdn.discordapp.com/attachments/169152372612923392/329054971452719105/unknown.png)](http://google.com.au/)
- Procure o local que seu arquivo foi baixado.
[![Foo](https://cdn.discordapp.com/attachments/169152372612923392/329055141951045634/unknown.png)](http://google.com.au/)
- Pronto Feito isso Você ja pode começar a codificar.
[![Foo](https://cdn.discordapp.com/attachments/169152372612923392/329055565944848394/unknown.png)](http://google.com.au/)
- A base do seu projeto ja está configura, e suas dependencias necessarias para o funcionamento do já foram baixadas. 
